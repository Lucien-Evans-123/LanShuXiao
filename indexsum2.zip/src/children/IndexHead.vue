<template>
  <el-menu
    :default-active="activeIndex"
    mode="horizontal"
    @select="handleSelect"
  >
    <el-menu-item index="1">所有文章</el-menu-item>
    <el-menu-item index="2"> 上传文章 </el-menu-item>
    <el-submenu index="3">
      <template slot="title">文章分类</template>
      <el-menu-item index="2-1">分类区1</el-menu-item>
      <el-menu-item index="2-2">分类区2</el-menu-item>
      <el-menu-item index="2-3">分类区3</el-menu-item>
    </el-submenu>
    <el-dropdown @command="handleCommand" class="user-avatar">
      <el-avatar
        src="https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png"
        size="medium"
      >
      </el-avatar>
      <el-dropdown-menu slot="dropdown">
        <el-dropdown-item command="a">用户主页</el-dropdown-item>
        <el-dropdown-item command="b">退出账号</el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>
  </el-menu>
</template>
  
<script>
import VueCookies from "vue-cookies";

export default {
  name: "IndexHead",
  data() {
    return {
      activeIndex: "1",
      usersearch: "",
    };
  },
  methods: {
    handleSelect(key, keyPath) {
      console.log("用户切换到:", key, keyPath);
      if (key == 1) {
        if (this.$router.currentRoute.name != "IndexPage") {
          this.$message("即将跳转到主页面");
          this.$router.push({ name: "IndexPage" });
        }else{
          this.$message("已经在当前页面，不进行跳转操作")
        }
      }
      if (key == 2) {
        if(this.$router.currentRoute.name != "UserUpload"){
          this.$message("即将跳转到上传页面");
          this.$router.push({name:"UserUpload"})
        }else{
          this.$message("已经在当前页面，不进行跳转操作")
        }
      }
    },
    handleCommand(command) {
      if (command == "a") {
        this.$message("即将跳转到用户主页面[开发中]");
      }
      if (command == "b") {
        this.$message("即将退出账号");

        //清楚cookies操作
        VueCookies.remove("isLogged");
        VueCookies.remove("username");

        this.$router.replace("/");
      }
    },
  },
};
</script>
  
  <style>
.user-avatar {
  float: right;
  margin-top: 12px;
  margin-right: 24px;
}

#el-menu-item-searchinput-container {
  cursor: default;
  opacity: 1;
  margin: 0 20px;
}
</style>