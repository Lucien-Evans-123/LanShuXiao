import Vue from "vue";
import Router from 'vue-router'
import UserLogin from '@/components/UserLogin.vue'
import UserRegister from '@/components/UserRegister.vue'
import IndexPage from '@/components/IndexPage.vue'
import UpLoadVue from '@/components/UpLoadVue.vue'
import EssayChoosePage1 from '@/components/EssayChoosePage1.vue'
import EssayChoosePage2 from '@/components/EssayChoosePage2.vue'
import EssayChoosePage3 from '@/components/EssayChoosePage3.vue'
import UserPage from '@/components/UserPage.vue'

// 引入cookie作为路由守卫判断用
import VueCookies from "vue-cookies"

Vue.use(Router)

const routes = [
  {
    path: '/',
    name: 'UserLogin',
    component: UserLogin
  },
  {
    path: '/register',
    name: 'UserRegister',
    component: UserRegister
  },
  {
    path: '/index',
    name: 'IndexPage',
    component: IndexPage,
    meta: { requiresAuth: true } },
  {
    path: '/upload',
    name: 'UserUpload',
    component: UpLoadVue,
    meta: { requiresAuth: true } 
  },
  {
    path:'/SCI1',
    name:'SCI1Essay',
    component:EssayChoosePage1,
    meta: { requiresAuth: true } 
  },
  {
    path:'/SCI2',
    name:'SCI2Essay',
    component:EssayChoosePage2,
    meta: { requiresAuth: true } 
  },
  {
    path:'/SCI3',
    name:'SCI3Essay',
    component:EssayChoosePage3,
    meta: { requiresAuth: true } 
  },
  {
    path:'/userPage',
    name:'UserPage',
    component:UserPage,
    meta: { requiresAuth: true } 
  }
]

const router = new Router({
  routes,
  mode: 'history'
})

// 设置路由守卫，防止用户不登陆就能够访问
router.beforeEach((to, from, next) => {
  const isAuthenticated = checkAuth();
  if (to.matched.some((route) => route.meta.requiresAuth)) { 
    if (isAuthenticated) {
      next();
    } else {
      next({ name: 'UserLogin' });
    }
  } else {
    next();
  }
})

// 用cookies检查用户是否已经登录
function checkAuth() {
  const isLoggedIn = VueCookies.get("isLogged");
  return isLoggedIn;
}

export default router;
