<template>
  <div class="card-layout">
    <div class="card" v-for="item in filteredCardData" :key="item.id">
      <div class="card-content">
        <h3 class="card-title">{{ item.title }}</h3>
        <p class="card-author">作者: {{ item.user.username }}</p>
        <p class="card-summary">摘要：{{ item.abs }}</p>
        <p class="card-summary">关键词：{{ getFormattedTags(item.tags) }}</p>
        <p class="card-summary">文章分区：{{ item.category.category_name }}</p>
        <el-button type="text" @click="viewcontent(item)">点击查看</el-button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import VueCookies from "vue-cookies"

export default {
  name: "UserPageMain",
  data() {
    return {
      cardData: [], // 存储卡片数据
    };
  },
  created() {
    this.fetchCardData();
  },
  methods: {
    fetchCardData() {
      axios
        .get("http://localhost:8081/index")
        .then((response) => {
          this.cardData = response.data.data.essayEntities; 
          console.log(this.cardData)
        })
        .catch((error) => {
          console.error("请求失败", error);
        });
    },
    getFormattedTags(tags) {
      if (tags.length === 0) {
        return ""; // 如果没有关键词，则显示为空字符串
      }
      const formattedTags = tags.map((tag) => `[${tag.tag_name}]`); // 将每个关键词格式化为 [关键词] 的形式
      return formattedTags.join(" "); // 使用空格连接所有关键词
    },
    viewcontent(item) {
      console.log(item.content);
      this.$alert(item.content, item.title, {
        confirmButtonText: '确定',
        center: true,
        callback: action => {
          console.log({
            type: '用户查看完成',
            message: `动作: ${action}`
          });
        }
      });
    }
  },
  computed: {
    filteredCardData() {
      const usernameTemp = VueCookies.get("username");
      return this.cardData.filter(item => item.user.username === usernameTemp);
    }
  }
};
</script>
