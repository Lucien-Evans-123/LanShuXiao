<template>
  <div class="card-layout">
    <div class="card" v-for="item in cardData" :key="item.id">
      <div class="card-content">
        <h3 class="card-title">{{ item.title }}</h3>
        <p class="card-author">{{ item.author }}</p>
        <p class="card-summary">{{ item.summary }}</p>
        <el-button type="text" @click="viewcontent(item.id)">点击查看</el-button>
      </div>
    </div>
  </div>
</template>
  
<script>
export default {
  name: "IndexMain",
  data() {
    return {
      cardData: [
        {
          id: 1,
          title: "Card 1",
          author: "Author 1",
          summary: "Summary 1",
        },
        {
          id: 2,
          title: "Card 2",
          author: "Author 2",
          summary: "Summary 2",
        },
        {
          id: 3,
          title: "Card 3",
          author: "Author 3",
          summary: "Summary 3",
        },
        {
          id: 4,
          title: "Card 4",
          author: "Author 4",
          summary: "Summary 4",
        },
        {
          id: 5,
          title: "Card 5",
          author: "Author 5",
          summary: "Summary 5",
        },
      ],
      currentPage: 1,
      pageSize: 1,
      totalItems: 2, // Total number of cards (should match the length of cardData array)
    };
  },
  methods: {
    handlePageChange(currentPage) {
      this.currentPage = currentPage;
    },
    viewcontent(item){
        this.$alert("用户点击了这个编号的文章",item)
    }
  },
};
</script>
  
  <style>
.card-layout {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  margin-bottom: 20px;
}

.card {
  width: 300px;
  margin: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

.card img {
  width: 100%;
  height: auto;
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
}

.card-content {
  padding: 10px;
}

.card-title {
  font-size: 18px;
  font-weight: bold;
}

.card-author {
  font-size: 14px;
  color: #999;
}

.card-summary {
  margin-top: 10px;
}

.pagination {
  display: flex;
  justify-content: center;
  margin-top: 20px;
}
</style>
  