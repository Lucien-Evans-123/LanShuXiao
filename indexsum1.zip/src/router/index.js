import Vue from "vue";
import Router from 'vue-router'
import UserLogin from '@/components/UserLogin.vue'
import UserRegister from '@/components/UserRegister.vue'
import IndexPage from '@/components/IndexPage.vue'
import UpLoadVue from '@/components/UpLoadVue.vue'

Vue.use(Router)

const routes = [
    {
        path:'/',
        name:'UserLogin',
        component:UserLogin
    },
    {
        path:'/register',
        name:'UserRegister',
        component:UserRegister
    },
    {
        path:'/index',
        name:'IndexPage',
        component:IndexPage
    },
    {
        path:'/upload',
        name:'UserUpload',
        component:UpLoadVue
    }
]

const router = new Router({
    routes,
    mode:'history'
});

export default router