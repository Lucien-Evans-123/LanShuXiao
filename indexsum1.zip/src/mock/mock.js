import Mock from "mockjs";

//登录假数据
Mock.mock("/user/login", "post", (options) => {
    const { username, password } = JSON.parse(options.body);
    // 假设用户名为admin，密码为123456登录成功
    if (username === "admin" && password === "123456") {
        return {
            code: 200,
            message: "登陆成功",
            data: {
                token: Mock.Random.guid(),
                username: "admin",
            },
        };
    } else {
        return {
            code: 401,
            message: "用户名错误",
            data: null,
        };
    }
});

//注册假数据
Mock.mock("/user/register", "post", (options) => {
  const { username, password } = JSON.parse(options.body);
  // 处理注册逻辑，可以根据需要进行验证、存储等操作
  if (username === "admin" && password === "123456") {
    return {
      code: 200,
      message: "注册成功",
      data: {
        username: username,
      },
    };
  } else {
    return {
      code: 400,
      message: "注册失败",
      data: null,
    };
  }
});