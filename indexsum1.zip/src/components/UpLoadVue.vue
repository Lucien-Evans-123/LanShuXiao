<template>
  <div>
    <IndexHead></IndexHead>
    <br />
    <el-form
      :model="ruleForm"
      ref="ruleForm"
      label-width="100px"
      class="demo-ruleForm"
    >
      <el-form-item label="文章名称" prop="essayname">
        <el-input
          v-model="ruleForm.name"
          maxlength="30"
          show-word-limit
          placeholder="请输入文章标题"
        ></el-input>
      </el-form-item>

      <el-form-item label="文章分类" prop="essaycategory">
        <el-select v-model="ruleForm.region" placeholder="请选择文章分类">
          <el-option label="分类一号" value="category1"></el-option>
          <el-option label="分类二号" value="category2"></el-option>
        </el-select>
      </el-form-item>

      <el-form-item label="文章标签">
        <el-tag
          :key="tag"
          v-for="tag in dynamicTags"
          closable
          :disable-transitions="false"
          @close="handleClose(tag)"
        >
          {{ tag }}
        </el-tag>
        <el-input
          class="input-new-tag"
          v-if="inputVisible"
          v-model="inputValue"
          ref="saveTagInput"
          size="medium"
          @keyup.enter.native="handleInputConfirm"
          @blur="handleInputConfirm"
        >
        </el-input>
        <el-button
          v-else
          class="button-new-tag"
          size="medium"
          @click="showInput"
          >添加标签</el-button
        >
      </el-form-item>

      <el-form-item label="正文内容">
        <el-input
          type="textarea"
          placeholder="请输入内容"
          v-model="textarea"
          maxlength="5000"
          show-word-limit
          rows="25"
        >
        </el-input>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" @click="submitForm('ruleForm')"
          >立即创建</el-button
        >
        <el-button @click="resetForm('ruleForm')">重置</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import IndexHead from "@/children/IndexHead.vue";

export default {
  name: "UpLoadVue",
  components: {
    IndexHead,
  },
  data() {
    return {
      ruleForm: {
        essayname: "",
        essaycategory: "",
      },
      fileList: [
        {
          name: "food.jpeg",
          url: "https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100",
        },
        {
          name: "food2.jpeg",
          url: "https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100",
        },
      ],
      dynamicTags: ["标签一", "标签二", "标签三"],
      inputVisible: false,
      inputValue: "",
      textarea: "",
    };
  },
  methods: {
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          alert("用户创建成功！");
        } else {
          console.log("创建失败！");
          return false;
        }
      });
    },

    //下面这些玩意我也看不懂，应该是控制台的一些返回值，没有这些上面的没法运行成功
    //等大概完成了估计要再下面添加给后端返回数据的代码
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    handleRemove(file, fileList) {
      console.log(file, fileList);
    },
    handlePreview(file) {
      console.log(file);
    },
    handleClose(tag) {
      this.dynamicTags.splice(this.dynamicTags.indexOf(tag), 1);
    },

    showInput() {
      this.inputVisible = true;
    },

    handleInputConfirm() {
      let inputValue = this.inputValue;
      if (inputValue) {
        this.dynamicTags.push(inputValue);
      }
      this.inputVisible = false;
      this.inputValue = "";
    },
  },
};
</script>

<style>
/* 普普通通的样式组件 */
.el-tag + .el-tag {
  margin-left: 10px;
}
.button-new-tag {
  margin-left: 10px;
  height: 32px;
  line-height: 30px;
  padding-top: 0;
  padding-bottom: 0;
}
.input-new-tag {
  width: 90px;
  margin-left: 10px;
  vertical-align: bottom;
}
</style>