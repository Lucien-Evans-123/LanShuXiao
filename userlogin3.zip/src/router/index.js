import Vue from 'vue';
import Router from 'vue-router';
import UserLogin from '../components/UserLogin.vue';
import UserRegister from '../components/UserRegister.vue';

Vue.use(Router);

const routes = [
    {
        path: '/',
        name: 'UserLogin',
        component: UserLogin
    },
    {
        path: '/register',
        name: 'UserRegister',
        component: UserRegister
    },
    {
        path:'*',
        redirect:'/'
    }
];

const router = new Router({
    routes,
    mode:'hash'
});

export default router;
