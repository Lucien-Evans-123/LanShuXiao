<template>
    <div>
      <el-form ref="registerForm" :model="registerData" label-width="100px">
        <el-form-item label="用户名" prop="username">
          <el-input v-model="registerData.username"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input type="password" v-model="registerData.password"></el-input>
        </el-form-item>
        <el-form-item label="邮箱" prop="email">
          <el-input v-model="registerData.email"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitForm">注册</el-button>
        </el-form-item>
      </el-form>
    </div>
  </template>
  
  <script>
  export default {
    name:'UserRegister',
    data() {
      return {
        registerData: {
          username: '',
          password: '',
          email: ''
        }
      };
    },
    methods: {
      submitForm() {
        this.$refs.registerForm.validate(valid => {
          if (valid) {
            // 在这里可以进行注册逻辑的处理，例如发送注册请求等
            console.log('注册成功');
          } else {
            console.log('表单验证不通过');
          }
        });
      }
    }
  };
  </script>