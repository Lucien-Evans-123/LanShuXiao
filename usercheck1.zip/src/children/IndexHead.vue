<template>
  <el-menu
    :default-active="activeIndex"
    mode="horizontal"
    @select="handleSelect"
  >
    <el-menu-item index="1">选项卡1</el-menu-item>
    <el-submenu index="2">
      <template slot="title">选项卡2</template>
      <el-menu-item index="2-1">选项2的子项1</el-menu-item>
      <el-menu-item index="2-2">选项2的子项2</el-menu-item>
      <el-menu-item index="2-3">选项2的子项3</el-menu-item>
      <el-submenu index="2-4">
        <template slot="title">选项2的子项4</template>
        <el-menu-item index="2-4-1">选项1</el-menu-item>
        <el-menu-item index="2-4-2">选项2</el-menu-item>
        <el-menu-item index="2-4-3">选项3</el-menu-item>
      </el-submenu>
    </el-submenu>
    <el-menu-item index="3">选项卡3</el-menu-item>
    <el-menu-item index="4"
      ><a href="https://www.baidu.com" target="_blank"
        >百度一下，你就知道</a
      ></el-menu-item
    >
    <el-menu-item id="el-menu-item-searchinput-container">
      <el-input v-model="usersearch" placeholder="搜索文章名称"></el-input>
    </el-menu-item>
    <el-dropdown @command="handleCommand" class="user-avatar">
      <el-avatar
        src="https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png"
        size="medium"
      >
      </el-avatar>
      <el-dropdown-menu slot="dropdown">
        <el-dropdown-item command="a">文章</el-dropdown-item>
        <el-dropdown-item command="b">标签</el-dropdown-item>
        <el-dropdown-item command="c">退出账号</el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>
  </el-menu>
</template>
  
  <script>
export default {
  name: "IndexHead",
  data() {
    return {
      activeIndex: "1",
      usersearch: "",
    };
  },
  methods: {
    handleSelect(key, keyPath) {
      console.log("用户切换到:", key, keyPath);
    },
    handleCommand(command) {
      this.$message("用户点击了" + command);
    },
  },
};
</script>
  
  <style>
.user-avatar {
  float: right;
  margin-top: 12px;
  margin-right: 24px;
}

#el-menu-item-searchinput-container {
  cursor: default;
  opacity: 1;
  margin: 0 20px;
}
</style>