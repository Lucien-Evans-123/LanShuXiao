<template>
  <div>
    <EssayVue></EssayVue>
    <EssayVue></EssayVue>
  </div>
</template>

<script>
import EssayVue from './EssayVue.vue'

export default {
    name:'IndexContent',
    components:{
        EssayVue
    }
}
</script>

<style>

</style>