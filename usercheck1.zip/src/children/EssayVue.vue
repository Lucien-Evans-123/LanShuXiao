<template>
  <el-row>
    <el-col :span="8">
      <div class="grid-content bg-purple-dark">
        <span
          ><img
            src="https://shadow.elemecdn.com/app/element/hamburger.9cf7b091-55e9-11e9-a976-7f4d0b07eef6.png"
            class="essay-image"
          />
        </span>
        <br>
        <a href="www.baidu.com">百度一下，你就知道</a>  
      </div>
    </el-col>
    <el-col :span="8">
      <div class="grid-content bg-purple-dark">
        <span
          ><img
            src="https://shadow.elemecdn.com/app/element/hamburger.9cf7b091-55e9-11e9-a976-7f4d0b07eef6.png"
            class="essay-image"
          />
        </span>
        <br>
        <a href="www.baidu.com">百度一下，你就知道</a>
      </div>
    </el-col>
    
  </el-row>
</template>

<script>
export default {
  name: "EssayVue",
};
</script>

<style>
.el-row {
  margin-bottom: 20px;
}
.el-col {
  border-radius: 4px;
  margin-right: 15px;
  margin-left: 15px;
}
.bg-purple-dark {
  background: #99a9bf;
}
.bg-purple {
  background: #d3dce6;
}
.bg-purple-light {
  background: #e5e9f2;
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
</style>