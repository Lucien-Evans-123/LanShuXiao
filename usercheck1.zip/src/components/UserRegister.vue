<template>
  <div class="user-register">
    <h2 class="register-title">用户注册</h2>
    <el-form
      class="register-form"
      ref="registerForm"
      :model="registerData"
      label-width="100px"
    >
      <el-form-item label="用户名" prop="username">
        <el-input
          v-model="registerData.username"
          placeholder="请输入用户名"
        ></el-input>
      </el-form-item>
      <el-form-item label="密码" prop="password">
        <el-input
          type="password"
          v-model="registerData.password"
          placeholder="请输入密码"
        ></el-input>
      </el-form-item>

      <el-button class="register-btn" type="primary" @click="submitForm"
        >注册</el-button
      >
    </el-form>
  </div>
</template>

<script>
export default {
  name: "UserRegister",
  data() {
    return {
      registerData: {
        username: "",
        password: "",
      },
    };
  },
  methods: {
    submitForm() {
      this.$refs.registerForm.validate((valid) => {
        if (valid) {
          // 在这里可以进行注册逻辑的处理，例如发送注册请求等
          console.log("注册成功");
        } else {
          console.log("表单验证不通过");
        }
      });
    },
  },
};
</script>

<style scoped>
.user-register {
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 100vh;
  background-color: #f5f7fa;
}

.register-title {
  margin-bottom: 20px;
  font-size: 24px;
  color: #333;
}

.register-form {
  width: 400px;
  background-color: #fff;
  border-radius: 4px;
  padding: 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.register-btn {
  width: 100%;
}
</style>
