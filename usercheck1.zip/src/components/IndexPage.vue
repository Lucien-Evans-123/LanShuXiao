<template>
  <div>
    <el-container>
      <IndexHead></IndexHead>
    </el-container>
    <IndexContent></IndexContent>
  </div>
</template>

<script>
import IndexContent from "@/children/IndexContent.vue";
import IndexHead from "@/children/IndexHead.vue";

export default {
  name: "IndexPage",
  components: {
    IndexHead,
    IndexContent
},
};
</script>

<style>
.el-header,
.el-footer {
  color: #333;
  text-align: center;
  line-height: 60px;
}

.el-main {
  background-color: #ffffff;
  color: #333;
  text-align: center;
  line-height: 160px;
}

body > .el-container {
  margin-bottom: 40px;
}

.el-container:nth-child(5) .el-aside,
.el-container:nth-child(6) .el-aside {
  line-height: 260px;
}

.el-container:nth-child(7) .el-aside {
  line-height: 320px;
}
</style>