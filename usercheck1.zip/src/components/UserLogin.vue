<template>
  <div class="login-container">
    <h2>用户登录</h2>
    <div class="form-group">
      <el-input placeholder="请输入账户名" v-model="FormData.username">
        <template slot="prepend">账号：</template>
      </el-input>
    </div>
    <div class="form-group">
      <el-input
        placeholder="请输入密码"
        v-model="FormData.password"
        show-password
      >
        <template slot="prepend">密码：</template>
      </el-input>
    </div>
    <div class="button-group">
      <el-button type="primary" plain @click="Login" style="width: 150px"
        >登录</el-button
      >
      <el-button type="info" plain @click="Register" style="width: 150px"
        >注册</el-button
      >
    </div>
  </div>
</template>
    
<script>
import axios from "axios";

import Mock from "mockjs";

Mock.mock("/user/login", "post", (options) => {
  const { username, password } = JSON.parse(options.body);
  // 假设用户名为admin，密码为123456登录成功
  if (username === "admin" && password === "123456") {
    return {
      code: 200,
      message: "登陆成功",
      data: {
        token: Mock.Random.guid(),
        username: "admin",
      },
    };
  } else {
    return {
      code: 401,
      message: "用户名错误",
      data: null,
    };
  }
});

export default {
  name: "UserLogin",
  data() {
    return {
      FormData: {
        username: "",
        password: "",
      },
    };
  },
  methods: {
    Login() {
      axios
        .post("/user/login", this.FormData)
        .then((response) => {
          console.log("用户执行登录请求");
          console.log(response.data);
          if (response.data.code === 200) {
            this.$router.push("/index");
          } else {
            console.log("登陆失败");
          }
        })
        .catch((error) => {
          console.error("请求失败", error);
        });
    },
    Register() {
      console.log("用户尝试注册");
      this.$router.push("/register");
    },
  },
};
</script>
  
<style>
.login-container {
  max-width: 400px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
  text-align: center;
}

.form-group {
  margin-bottom: 20px;
  margin-top: 20px;
}

.button-group {
  margin: auto;
}
</style>