import Vue from "vue";
import Router from 'vue-router'
import UserLogin from '@/components/UserLogin.vue'
import IndexPage from '@/components/IndexPage.vue'
import UserRegister from '@/components/UserRegister.vue'

Vue.use(Router)

const routes = [
    {
        path:'/userlogin',
        name:'UserLogin',
        component:UserLogin
    },
    {
        path:'/index',
        name:'IndexPage',
        component:IndexPage
    },
    {
        path:'/register',
        name:'UserRegister',
        component:UserRegister
    }
]

const router = new Router({
    routes,
    mode:'history'
});

export default router