<template>
  <div>
    <HeadVue></HeadVue>
    <el-main>
      <UpLoadVue></UpLoadVue>
    </el-main>
  </div>
</template>

<script>
import HeadVue from "./components/HeadVue.vue";
import UpLoadVue from './components/UpLoadVue.vue';

export default {
  name: "App",
  components: {
    HeadVue,
    UpLoadVue
  },
};
</script>

<style>
</style>