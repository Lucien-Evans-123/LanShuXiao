import VueRouter from "vue-router";
import UserLogin from '../components/UserLogin.vue'
import UserRegister from '../components/UserRegister.vue'

export default new VueRouter({
    routes:[
        {
            path:'/login',
            component:UserLogin
        },
        {
            path:'/register',
            component:UserRegister
        }
    ]
})