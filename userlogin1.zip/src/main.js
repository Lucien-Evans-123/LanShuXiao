import Vue from 'vue'
import App from './App.vue'
//引入elementui和对应组件库
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'

//使用vue-router路由
import VueRouter from 'vue-router'
import router from './router'

Vue.config.productionTip = true
//使用elementui和router
Vue.use(ElementUI)
Vue.use(VueRouter)

new Vue({
  render: h => h(App),
  router:router
}).$mount('#app')
