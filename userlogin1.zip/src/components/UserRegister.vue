<template>
  <div class="Register-container">
    <h2>用户注册</h2>
    <div class="form-group">
      <el-input placeholder="请输入账户名" v-model="username">
        <template slot="prepend">账号：</template>
      </el-input>
    </div>
    <div class="form-group">
      <el-input placeholder="请输入密码" v-model="password" show-password>
        <template slot="prepend">密码：</template>
      </el-input>
    </div>
    <div class="button-group">
        <el-button type="info" plain @click="Register" style="width:200px;">注册</el-button>
    </div>
  </div>
</template>

<script>
export default {
    name:'UserRegister',
    data(){
        return{
            username:"",
            password:"",
        }
    },
    methods:{
        Register(){
            console.log("用户点击了注册按钮")
        }
    }
}
</script>

<style>
.Register-container {
  max-width: 400px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
  text-align: center;
}

.form-group {
  margin-bottom: 20px;
  margin-top: 20px;
}

.button-group{
  margin: auto;
}

</style>