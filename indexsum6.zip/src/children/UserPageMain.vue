<template>
  <div class="card-layout">
    <div class="card" v-for="item in filteredCardData" :key="item.id">
      <div class="card-content">
        <h3 class="card-title">{{ item.title }}</h3>
        <p class="card-author">作者: {{ item.user.username }}</p>
        <p class="card-summary">摘要：{{ item.abs }}</p>
        <p class="card-summary">关键词：{{ getFormattedTags(item.tags) }}</p>
        <p class="card-summary">文章分区：{{ item.category.category_name }}</p>
        <el-button type="text" @click="viewcontent(item)">点击查看</el-button>
        <el-button type="text" @click="deleteCard(item)">删除</el-button>
        <el-button type="text" @click="showUpdateForm(item)">更新</el-button>
      </div>
    </div>
    <el-dialog title="更新文章" :visible.sync="updateFormVisible">
      <el-form :model="updateFormData">
        <el-form-item label="标题">
          <el-input v-model="updateFormData.title"></el-input>
        </el-form-item>
        <el-form-item label="摘要">
          <el-input v-model="updateFormData.abs"></el-input>
        </el-form-item>
        <el-form-item label="内容">
          <el-input type="textarea" v-model="updateFormData.content" rows="15"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="updateFormVisible = false">取消</el-button>
        <el-button type="primary" @click="updateArticle">保存</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import axios from "axios";
import VueCookies from "vue-cookies";

export default {
  name: "UserPageMain",
  data() {
    return {
      cardData: [], // 存储卡片数据
      updateFormVisible: false,
    updateFormData: {
      passage_id: null,
      user: {
        user_id: null,
        username: null
      },
      content: "",
      abs: "",
      title: "",
      published: null,
      category: {
        category_id: null,
        category_name: ""
      },
      tags: [],
      createTime: null,
      updateTime: null,
      cover_photo: null
    },
    };
  },
  created() {
    this.fetchCardData();
  },
  methods: {
    showUpdateForm(item) {
    this.updateFormData = JSON.parse(JSON.stringify(item)); // 深拷贝以避免直接修改原始数据
    this.updateFormVisible = true;
  },
  updateArticle() {
    axios
      .post("http://localhost:8081/essay/update", this.updateFormData)
      .then((response) => {
        console.log("更新成功", response);
        this.updateFormVisible = false;
        this.fetchCardData(); // 重新获取卡片数据以更新视图
      })
      .catch((error) => {
        console.error("更新失败", error);
      });
  },
    fetchCardData() {
      axios
        .get("http://localhost:8081/index")
        .then((response) => {
          this.cardData = response.data.data.essayEntities;
          console.log(this.cardData);
        })
        .catch((error) => {
          console.error("请求失败", error);
        });
    },
    getFormattedTags(tags) {
      if (tags.length === 0) {
        return ""; // 如果没有关键词，则显示为空字符串
      }
      const formattedTags = tags.map((tag) => `[${tag.tag_name}]`); // 将每个关键词格式化为 [关键词] 的形式
      return formattedTags.join(" "); // 使用空格连接所有关键词
    },
    viewcontent(item) {
      console.log(item.content);
      this.$alert(item.content, item.title, {
        confirmButtonText: "确定",
        center: true,
        callback: (action) => {
          console.log({
            type: "用户查看完成",
            message: `动作: ${action}`,
          });
        },
      });
    },
    deleteCard(item) {
      axios
        .post("http://localhost:8081/essay/delete", {
          passage_id: item.passage_id,
          user: {
            user_id: item.user.user_id,
            username: item.user.username,
          },
          content: item.content,
          abs: item.abs,
          title: item.title,
          published: item.published,
          category: {
            category_id: item.category.category_id,
            category_name: item.category.category_name,
          },
          tags: item.tags,
          createTime: item.createTime,
          updateTime: item.updateTime,
          cover_photo: item.cover_photo,
        })
        .then((response) => {
          console.log("删除成功", response);
          this.fetchCardData(); // 重新获取卡片数据以更新视图
        })
        .catch((error) => {
          console.error("删除失败", error);
        });
    },
  },
  computed: {
    filteredCardData() {
      const usernameTemp = VueCookies.get("username");
      return this.cardData.filter(
        (item) => item.user.username === usernameTemp
      );
    },
  },
};
</script>
