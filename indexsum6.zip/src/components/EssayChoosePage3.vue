<template>
  <div>
    <IndexHead></IndexHead>
    <EssayChoose3></EssayChoose3>
  </div>
</template>

<script>
import IndexHead from '@/children/IndexHead.vue';
import EssayChoose3 from '@/children/EssayChooseMain3.vue';

export default {
    name:"EssayChoosePage2",
    components:{
        IndexHead,
        EssayChoose3
    }
}
</script>

<style>
.el-header,
.el-footer {
  color: #333;
  text-align: center;
  line-height: 60px;
}

.el-main {
  background-color: #ffffff;
  color: #333;
  text-align: center;
  line-height: 160px;
}

body > .el-container {
  margin-bottom: 40px;
}

.el-container:nth-child(5) .el-aside,
.el-container:nth-child(6) .el-aside {
  line-height: 260px;
}

.el-container:nth-child(7) .el-aside {
  line-height: 320px;
}
</style>