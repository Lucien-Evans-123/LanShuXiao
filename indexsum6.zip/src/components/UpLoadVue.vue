<template>
  <div>
    <IndexHead></IndexHead>
    <br />
    <el-form
      :model="form"
      label-width="80px"
      @submit.native.prevent="submitForm"
    >
      <el-form-item label="文章标题">
        <el-input v-model="form.title"></el-input>
      </el-form-item>
      <el-form-item label="文章摘要">
        <el-input v-model="form.abs"></el-input>
      </el-form-item>
      <el-form-item label="文章分类">
        <el-select
          v-model="form.category.category_id"
          placeholder="请选择文章分类"
        >
          <el-option
            v-for="category in categories"
            :key="category.category_id"
            :value="category.category_id"
            :label="category.category_name"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="文章标签">
        <el-tag
          :key="tag.tag_name"
          v-for="tag in form.tags"
          closable
          :disable-transitions="false"
          @close="handleClose(tag)"
        >
          {{ tag.tag_name }}
        </el-tag>
        <el-input
          class="input-new-tag"
          v-if="inputVisible"
          v-model="inputValue"
          ref="saveTagInput"
          size="medium"
          @keyup.enter.native="handleInputConfirm"
          @blur="handleInputConfirm"
        >
        </el-input>
        <el-button
          v-else
          class="button-new-tag"
          size="medium"
          @click="showInput"
          >添加标签</el-button
        >
      </el-form-item>
      <el-form-item label="正文内容">
        <el-input
          type="textarea"
          placeholder="请输入内容"
          v-model="form.content"
          maxlength="5000"
          show-word-limit
          rows="25"
        >
        </el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" native-type="submit">提交</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import axios from "axios";
import IndexHead from "@/children/IndexHead.vue";
import { mapState } from "vuex";
import  VueCookies  from "vue-cookies";

export default {
  computed: {
    ...mapState(["userid"]),
  },
  components: {
    IndexHead,
  },
  data() {
    return {
      form: {
        passage_id: null,
        user: {
          user_id: null,
          username: null,
        },
        content: "在这里输入文章内容",
        abs: "在这里输入文章摘要",
        title: "在这里输入文章标题",
        published: null,
        category: {
          category_id: 1,
          category_name: "",
        },
        tags: [
          {
            tag_id: null,
            tag_name: "标签1",
          },
          {
            tag_id: null,
            tag_name: "标签2",
          },
        ],
        createTime: null,
        updateTime: null,
        cover_photo: null,
      },
      inputValue: "",
      inputVisible: false,
      categories: [], // 文章分类选项
    };
  },
  mounted() {
    const username_temp = VueCookies.get("username");
    this.form.user.username = username_temp;

    this.fetchCategories(); // 获取文章分类选项
    this.form.user.user_id = this.userid; //获取用户id
  },
  methods: {
    submitForm() {
      axios
        .post("http://localhost:8081/essay/create", this.form)
        .then((response) => {
          console.log(response.data); // 输出后端返回的响应数据
          if (response.data.code === 200) {
            this.$message.success("上传成功");
          }
        })
        .catch((error) => {
          console.error("请求失败", error);
          this.$message.error("上传失败");
        });
    },
    handleClose(tag) {
      this.form.tags = this.form.tags.filter(
        (t) => t.tag_name !== tag.tag_name
      );
    },
    handleInputConfirm() {
      let inputValue = this.inputValue;
      if (inputValue) {
        this.form.tags.push({
          tag_id: null,
          tag_name: inputValue,
        });
      }
      this.inputVisible = false;
      this.inputValue = "";
    },
    showInput() {
      this.inputVisible = true;
      this.$nextTick(() => {
        this.$refs.saveTagInput.focus();
      });
    },
    fetchCategories() {
      // 发起请求获取文章分类选项，示例数据
      const categories = [
        { category_id: 1, category_name: "SCI 1区" },
        { category_id: 2, category_name: "SCI 2区" },
        { category_id: 3, category_name: "SCI 3区" },
      ];
      this.categories = categories;
    },
  },
};
</script>


<style>
.el-tag + .el-tag {
  margin-left: 10px;
}
.button-new-tag {
  margin-left: 10px;
  height: 32px;
  line-height: 30px;
  padding-top: 0;
  padding-bottom: 0;
}
.input-new-tag {
  width: 90px;
  margin-left: 10px;
  vertical-align: bottom;
}
</style>