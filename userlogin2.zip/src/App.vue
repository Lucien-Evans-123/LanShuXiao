<template>
  <UserLogin></UserLogin>
</template>

<script>

import UserLogin from '@/components/UserLogin.vue'

export default {
  name:'App',
  components:{
    UserLogin
  }
}
</script>

<style>

</style>