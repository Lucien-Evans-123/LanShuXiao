<template>
  <div class="block">
  <el-pagination
    layout="prev, pager, next"
    :total="50">
  </el-pagination>
</div>
</template>

<script>
export default {
    name:'FootVue'
}
</script>

<style>

</style>