<template>
  <div>
    <EssayVue></EssayVue>
    <EssayVue></EssayVue>
  </div>
</template>

<script>
import EssayVue from "../../../usercheck1/src/children/EssayVue.vue.js";

export default {
  name: "ContentVue",
  components: {
    EssayVue,
  },
};
</script>

<style>
</style>