import Mock from "mockjs";


// 存储用户数据的数组
let userList = [{ username: "admin", password: "123456" }, { username: "tom", password: "123456" }
];

// 拦截 /user/register 请求，接收并存储数据
Mock.mock('/user/register', 'post', (options) => {
  const { username, password } = JSON.parse(options.body);

  // 检查用户名是否已存在
  const userExists = userList.some(user => user.username === username);

  if (userExists) {
    return {
      code: 400,
      message: '注册失败，用户名已存在',
      data: null,
    };
  } else {
    // 添加用户到列表
    userList.push({ username, password });
    return {
      code: 200,
      message: '注册成功',
      data: {
        username,
      },
    };
  }
});

// 拦截 /user/login 请求，查找用户名和密码是否正确
Mock.mock('/user/login', 'post', (options) => {
  const { username, password } = JSON.parse(options.body);
  // 查找用户
  const user = userList.find(user => user.username === username && user.password === password);
  if (user) {
    return {
      code: 200,
      message: '登录成功',
      data: {
        token: 'your-token',
        username: user.username,
      },
    };
  } else {
    return {
      code: 401,
      message: '登录失败，用户名或密码错误',
      data: null,
    };
  }
});


//主页面文章假数据100条
Mock.mock("/essay/category", "get", {
  "list": [
    {
      title: "ChatGPT的运行模式、关键技术及未来图景",
      author: "admin",
      summary: "美国人工智能实验室OpenAI开发的人工智能聊天机器人应用ChatGPT引发广泛热议，被认为是继互联网、智能手机之后，带给人类的第三次革命性产品。互联网开辟了“空间革命”，智能手机的出现带来“时间革命”，ChatGPT的横空出世有望形成“思维革命”，通过替代人类进行创作、创意、解答、咨询、翻译和客服等改变人类思考和处理问题的方式方法，由此重塑各行业生态乃至整个世界。",
      region: "SCI 1",
      keyword: [{ keywordname: "ChatGPT" }, { keywordname: "语言模型" }],
      textarea: "2022年11月上线的ChatGPT是由美国人工智能实验室OpenAl开发的人工智能聊天机器人应用，上线不到一周用户突破100万，两个月时间吸引活跃用户超亿人，打破抖音9个月吸引用户过亿的记录，成为历史上用户增长速度最快的应用程序。回顾ChatGPT的发展历程可知，OpenAl自GPT 1.0开始，就将大型语言模型(Large Language Model,LLM) 视为通往通用人工智能(Artifcial General Intelligence,AGI)的必由之路。具体而言，在OpenAl看来，未来的AGI应拥有一个与任务无关的超大型LLM，可以从海量的数据中学习各种知识，LLM以生成一切的方式解决各类实际问题。除此之外，AGI能够听懂人类的命令，便于人类使用。"
    },
    {
      title: "ChatGPT爆火后关于科技伦理及学术伦理的冷思考",
      author: "admin",
      summary: "ChatGPT以通用人工智能的高科技姿态横空问世后，赢得业界青睐及全球热议。随之关于人工智能的伦理考量与忧虑在业界引发广泛关注。ChatGPT“更像人类一样说话”让具有深度学习力的强人工智能语言模型在科技史上成为一座里程碑。文本从科技伦理及学术伦理视角出发，在实证研究视域中考察ChatGPT的思考力与回答力，并对其语言能力、语言风格、论证效力及思想深度作出特征性分析与描述，旨在对其进行伦理考量。文本旨在客观考证ChatGPT是否具有道德伦理偏差偏见及其引发的科技伦理与学术伦理问题，厘清其中的技术机制与伦理成因，从全面性、可靠性、严谨性、深刻性、原创性等五个方面对ChatGPT的学术伦理要素进行分析，并从内部规训与外部规约两大维度对道德判断、数据泄漏、考试作弊与学术抄袭、作者署名权之争等问题提供应对之策。",
      region: "SCI 2",
      keyword: [{ keywordname: "ChatGPT" }, { keywordname: "大语言模型" }, { keywordname: "通用人工智能" }, { keywordname: "科技伦理" }, { keywordname: "学术伦理" }],
      textarea: "ChatGPT的爆火引发了人们对科技伦理和学术伦理的深刻思考。这一现象激发了人们对于人工智能在日常交流中所引发的伦理问题的关注，同时也加强了对于研究伦理的重要性的认识。这场冷思考将推动我们更加深入地探讨和解决与技术发展相关的道德和伦理难题。"
    },
    {
      title: "从图灵测试到ChatGPT——人机对话的里程碑及启示",
      author: "admin",
      summary: "图灵奖得主、深度学习之父辛顿(Geoff Hinton)说：“深度学习的下一个大的进展应当是让神经网络真正理解文档的内容。”机器学习著名学者乔丹(Michael Jordan)说：“如果给我10亿美元，我会用这10亿美元建造一个NASA1级别的自然语言研究项目。”图灵奖得主杨乐昆(Yann LeCun)说：“深度学习的下一个前沿课题是自然语言理解。”微软全球执行副总裁沈向洋说：“下一个十年，懂语言者得天下。”微软创始人比尔·盖茨(Bill Gates)2019年6月在华盛顿经济俱乐部午餐会接受采访时说：“我将创建一家人工智能公司，目标是让计算机学会阅读，能够吸收和理解全世界所有的书面知识。”",
      region: "SCI 3",
      keyword: [{ keywordname: "ChatGPT" }, { keywordname: "大语言模型" }, { keywordname: "通用人工智能" }, { keywordname: "科技伦理" }, { keywordname: "学术伦理" }],
      textarea: "从图灵测试到ChatGPT，人机对话迈出了重要的里程碑。这一演进展示了人工智能在语言理解和生成方面的巨大进步。同时，我们也应从中获得启示，意识到人机对话的伦理、隐私和安全挑战。这将引导我们更加谨慎地推动人工智能技术的发展与应用。"
    },
    {
      title: "生成式人工智能的教育应用与展望——以ChatGPT系统为例",
      author: "tom",
      summary: "生成式人工智能（Generative Artificial Intelligence）旨在利用人工智能技术自动化生成文本、图像、视频、音频等多模态数据，受到教育领域的广泛关注。其中，ChatGPT系统因其良好的自然语言理解和生成能力，体现出较高的多领域应用潜力。本研究以ChatGPT作为主要对象，基于其四项核心能力，即启发性内容生成能力、对话情境理解能力、序列任务执行能力和程序语言解析能力，探讨在教师教学、学习过程、教育评价、学业辅导四个方面的潜在教育应用。在此基础上，在真实系统中进行了习题生成、自动解题、辅助批阅等教育应用的初步验证。最后，本文进一步探讨了以ChatGPT为代表的生成式人工智能在教育应用中所面临的局限和对教育的启示。",
      region: "SCI 3",
      keyword: [{ keywordname: "ChatGPT" }, { keywordname: "大语言模型" }, { keywordname: "通用人工智能" }, { keywordname: "科技伦理" }, { keywordname: "学术伦理" }],
      textarea: "ChatGPT系统代表了生成式人工智能在教育领域的应用前景。它具备与学生互动的能力，能够提供个性化的教学辅助和知识传授。未来，ChatGPT系统有望在远程教育、个性化学习和智能辅导方面发挥重要作用。然而，我们也需要关注教育伦理、数据隐私和技术可信度等问题，以确保生成式人工智能在教育中发挥正面而可持续的影响。"
    },
    {
      title: "“阿拉丁神灯”还是“潘多拉魔盒”：ChatGPT教育应用的潜能与风险",
      author: "tom",
      summary: "智能聊天机器人模型ChatGPT，因具有可以针对用户输入内容生成自然语言文本，支持连续多轮对话与上下文理解等特性，吸引了大量教育研究者和工作者的关注。作为AIGC的典型应用，ChatGPT会如何改变教育？它到底是教育的“阿拉丁神灯”还是“潘多拉魔盒”呢？一方面，ChatGPT具有赋能教学创新的潜能，可以提升教学成果的完成度与创意感、增强数字导师的角色感与互动性、提高自适应学习系统的易用性与精准度、促进教学策略与方式的智慧化与创造性，支持教学反馈与评价的生成性与个性化。另一方面，ChatGPT在教育中的应用也可能引发四类风险：学业诚信遭质疑与评估机制失平衡、过度依赖生沉迷与教师地位恐弱化、信息传输不准确与知识水平受限制、伦理意识未加强与伦理风险难应对。显而易见，作为一款现象级生成式人工智能应用，ChatGPT可能引发教育的深刻变革。教育工作者应谨慎地加以使用，积极吸纳ChatGPT带来的教育创新，同时通过发展评估策略、分割教学责任、加速技术革新、制定伦理指南等措施规避其可能带来的教育风险。",
      region: "SCI 1",
      keyword: [{ keywordname: "ChatGPT" }, { keywordname: "大语言模型" }, { keywordname: "通用人工智能" }, { keywordname: "科技伦理" }, { keywordname: "学术伦理" }],
      textarea: "ChatGPT的教育应用潜能巨大，但也存在风险。像阿拉丁神灯一样，它可以为学生提供个性化的学习支持，激发创造力和批判性思维。然而，如同潘多拉魔盒，不适当的使用可能导致问题。可能存在误导、错误或有偏见的信息传递，以及对学生的过度依赖。此外，数据隐私和安全问题也需要谨慎处理。确保使用ChatGPT的教育应用时进行有效监督，平衡其潜能与风险，是至关重要的。"
    },
    {
      title: "人工智能生成内容（AIGC）对学术生态的影响与应对——基于ChatGPT的讨论与分析",
      author: "tom",
      summary: "以ChatGPT为代表的人工智能生成内容（AIGC）发展日益蓬勃，引起了业界与学界的广泛讨论，然而目前对于AIGC如何影响学术生态的讨论尚不系统。文章首先梳理了AIGC的源起与发展，并讨论了ChatGPT带来的新变革。然后基于学术生态的基本概念构建分析框架，讨论了AIGC对学术生产、学术评价、学术传播方面的影响，并以ChatGPT为例进行了具体分析与讨论。研究认为，以ChatGPT为代表的AIGC可以在知识生产、科学评价、快速传播等方面发挥作用，但也可能造成责任分散、潜在歧视与信任危机。最后，文章讨论了如何应对AIGC带来的风险挑战。未来需要进一步强化责任规范、构建审查机制与推动研究透明。本研究为政策制定者理解AIGC对学术生态的影响提供了一个理解视角，并对如何科学合理使用AIGC提出了逻辑进路，旨在为未来学术生态的良性健康发展提供参考。",
      region: "SCI 2",
      keyword: [{ keywordname: "ChatGPT" }, { keywordname: "大语言模型" }, { keywordname: "通用人工智能" }, { keywordname: "科技伦理" }, { keywordname: "学术伦理" }],
      textarea: "人工智能生成内容（AIGC），包括ChatGPT在内，对学术生态有着深远影响，同时也带来了一些挑战。AIGC的快速生成能力提供了大量的研究素材和信息资源，为学术界带来了便利。然而，它也引发了学术伦理和学术诚信的担忧。有可能出现抄袭、知识产权侵犯和论文质量问题等风险。为了应对AIGC的影响，学术界需要制定明确的道德准则和使用规范。这可能包括强调独创性和原创性的重要性，规范AIGC在研究和写作过程中的使用。此外，学术界还应投入更多的资源来开发和应用技术工具，以便检测和防范AIGC生成内容的滥用。同时，加强教育和培训，提高研究人员和学生对学术诚信的意识和理解，也是关键的措施之一。"
    },
  ],
});

//接受用户提交的数据
Mock.mock('/essay/create', 'post', (options) => {
  const data = JSON.parse(options.body); // 解析前端提交的 JSON 数据
  console.log('接收到前端提交的数据:', data);
  // 在这里进行你想要的处理，比如保存数据到数据库等

  // 返回一个包含处理结果的响应数据
  return {
    code: 200,
    message: '提交成功',
  };
});