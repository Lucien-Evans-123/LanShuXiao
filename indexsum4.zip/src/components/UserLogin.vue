<template>
  <div class="centered-page">
    <div class="login-container">
    <h2>用户登录</h2>
    <div class="form-group">
      <el-input placeholder="请输入账户名" v-model="FormData.username">
        <template slot="prepend">账号：</template>
      </el-input>
    </div>
    <div class="form-group">
      <el-input
        placeholder="请输入密码"
        v-model="FormData.password"
        show-password
      >
        <template slot="prepend">密码：</template>
      </el-input>
    </div>
    <div class="button-group">
      <el-button type="primary" plain @click="Login" style="width: 150px"
        >登录</el-button
      >
      <el-button type="info" plain @click="Register" style="width: 150px"
        >注册</el-button
      >
    </div>
  </div>
  </div>
    
  
</template>

<script>
import axios from "axios";
import VueCookies from "vue-cookies"

export default {
  name: "UserLogin",
  data() {
    return {
      FormData: {
        username: "",
        password: "",
      },
    };
  },
  mounted() {
    //检查是否存在登录标识，如果存在则直接跳转到首页
    if(VueCookies.get("isLogged")){
      this.$router.replace("/index");
    }
  },
  methods: {
    Login() {
      axios
        .post("/user/login", this.FormData)
        .then((response) => {
          console.log("用户执行登录请求");
          console.log(response.data);
          if (response.data.code === 200) {
            this.$message("登录成功！");

            //设置cookies
            VueCookies.set("isLogged",true)
            VueCookies.set("username",this.FormData.username)

            //检查用户cookies
            const username_temp = VueCookies.get("username")
            const islogged_temp = VueCookies.get("isLogged")
            console.log(username_temp)
            console.log(islogged_temp)

            this.$router.push("/index");
          } else {
            this.$message("登录失败！请检查用户名和密码！");
          }
        })
        .catch((error) => {
          console.error("请求失败", error);
        });
    },
    Register() {
      console.log("用户尝试注册");
      this.$router.replace("/register");
    },
  },
};
</script>

<style>

.centered-page {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f1f1f1;
}

.login-container {
  max-width: 400px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
  text-align: center;
  background-color: #f5f5f5;
}

.form-group {
  margin-bottom: 20px;
}

.button-group {
  display: flex;
  justify-content: center;
}

.el-button {
  margin: 0 10px;
}
</style>
