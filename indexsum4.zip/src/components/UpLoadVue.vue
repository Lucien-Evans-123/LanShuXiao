<template>
  <div>
    <IndexHead></IndexHead>
    <br />
    <el-form ref="form" :model="form" label-width="80px">
      <el-form-item label="文章标题">
        <el-input v-model="form.title"></el-input>
      </el-form-item>

      <el-form-item label="文章摘要">
        <el-input v-model="form.summary"></el-input>
      </el-form-item>

      <el-form-item label="文章分类">
        <el-select v-model="form.region" placeholder="请选择文章分类">
          <el-option label="分类一" value="1"></el-option>
          <el-option label="分类二" value="2"></el-option>
          <el-option label="分类三" value="3"></el-option>
        </el-select>
      </el-form-item>

      <el-form-item label="文章标签">
        <el-tag
          :key="tag"
          v-for="tag in form.keyword"
          closable
          :disable-transitions="false"
          @close="handleClose(tag)"
        >
          {{ tag }}
        </el-tag>
        <el-input
          class="input-new-tag"
          v-if="inputVisible"
          v-model="inputValue"
          ref="saveTagInput"
          size="medium"
          @keyup.enter.native="handleInputConfirm"
          @blur="handleInputConfirm"
        >
        </el-input>
        <el-button
          v-else
          class="button-new-tag"
          size="medium"
          @click="showInput"
          >添加标签</el-button
        >
      </el-form-item>

      <el-form-item label="正文内容">
        <el-input
          type="textarea"
          placeholder="请输入内容"
          v-model="form.textarea"
          maxlength="5000"
          show-word-limit
          rows="25"
        >
        </el-input>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" @click="submitForm(form)">立即创建</el-button>
        <el-button>返回首页</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import IndexHead from "@/children/IndexHead.vue";
import axios from "axios";
import VueCookies from "vue-cookies"

export default {
  name: "UpLoadVue",
  components: {
    IndexHead,
  },
  data() {
    return {
      form: {
        title: "",
        author:"",
        region: "",
        summary: "",
        keyword: ["标签一", "标签二", "标签三"],
        textarea: "",
      },
      inputValue: "",
      inputVisible: false,
    };
  },
  methods: {
    submitForm(form) {
      const username_temp = VueCookies.get("username")
      this.form.author = username_temp
      console.log(form);
      axios
        .post("/essay/create", this.form)
        .then((response) => {
          console.log(response.data); // 输出后端返回的响应数据
          if(response.data.code == 200){
            this.$alert("用户提交成功！")
            this.$router.replace('/index')
          }
        })
        .catch((error) => {
          console.error("请求失败", error);
        });
    },

    //下面是添加标签的函数
    handleClose(tag) {
      this.form.keyword.splice(this.form.keyword.indexOf(tag), 1);
    },
    handleInputConfirm() {
      let inputValue = this.inputValue;
      if (inputValue) {
        this.form.keyword.push(inputValue);
      }
      this.inputVisible = false;
      this.inputValue = "";
    },
    showInput() {
      this.inputVisible = true;
    },
  },
};
</script>

<style>
.el-tag + .el-tag {
  margin-left: 10px;
}
.button-new-tag {
  margin-left: 10px;
  height: 32px;
  line-height: 30px;
  padding-top: 0;
  padding-bottom: 0;
}
.input-new-tag {
  width: 90px;
  margin-left: 10px;
  vertical-align: bottom;
}
</style>