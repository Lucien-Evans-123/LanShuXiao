<template>
  <div class="card-layout">
    <div class="card" v-for="item in filteredCardData" :key="item.id">
      <div class="card-content">
        <h3 class="card-title">{{ item.title }}</h3>
        <p class="card-author">作者:{{ item.author }}</p>
        <p class="card-summary">摘要：{{ item.summary }}</p>
        <p class="card-summary">关键词：{{ item.keyword }}</p>
        <p class="card-summary">文章分区：{{ item.region }}</p>
        <el-button type="text" @click="viewcontent(item)">点击查看</el-button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import VueCookies from "vue-cookies"

export default {
  name: "UserPageMain",
  data() {
    return {
      cardData: [], // 存储卡片数据
    };
  },
  created() {
    this.fetchCardData();
  },
  methods: {
    fetchCardData() {
      axios
        .get("/essay/category")
        .then((response) => {
          this.cardData = response.data.list;
        })
        .catch((error) => {
          console.error("请求失败", error);
        });
    },
    viewcontent(item) {
      console.log(item.textarea);
      this.$alert(item.textarea, item.title, {
        confirmButtonText: '确定',
        center: true,
        callback: action => {
          console.log({
            type: '用户查看完成',
            message: `动作: ${action}`
          });
        }
      });
    }
  },
  computed: {
    filteredCardData() {
      const username_temp = VueCookies.get("username")
      return this.cardData.filter(item => item.author == username_temp);
    }
  }
};
</script>
