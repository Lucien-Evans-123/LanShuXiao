<template>
  <div class="card-layout">
    <div class="card" v-for="item in cardData" :key="item.id">
      <div class="card-content">
        <h3 class="card-title">{{ item.title }}</h3>
        <p class="card-author">作者:{{ item.author }}</p>
        <p class="card-summary">摘要：{{ item.summary }}</p>
        <p class="card-summary">关键词：
          <span v-for="keyword in item.keyword" :key="keyword.keywordid">
            {{ keyword.keywordname }}
            <span v-if="!isLastKeyword(item.keyword, keyword)">, </span>
          </span>
        </p>
        <p class="card-summary">文章分区：{{ item.region }}</p>
        <el-button type="text" @click="viewcontent(item)">点击查看</el-button>
      </div>
    </div>
  </div>
</template>
  
<script>
import axios from 'axios';
export default {
  name: "IndexMain",
  data() {
    return {
      maintextview:false,
      cardData: [], // 存储卡片数据
    };
  },
  created() {
    this.fetchCardData();
  },
  methods: {
    fetchCardData() {
      axios
        .get("/essay/category")
        .then((response) => {
          this.cardData = response.data.list; 
        })
        .catch((error) => {
          console.error("请求失败", error);
        });
    },
    
    //消除最后一个标签的逗号
    isLastKeyword(keywordArray, keyword) {
      return keywordArray.indexOf(keyword) === keywordArray.length - 1;
    },
    
    viewcontent(item) {
      console.log(item);
      this.$alert(item.textarea,item.title,{
          confirmButtonText: '确定',
          center:true,
          callback: action => {
            console.log({
              type: '用户查看完成',
              message: `动作: ${ action }`
            });
          }})
    }
  },
};
</script>

  
  <style>
.card-layout {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  margin-bottom: 20px;
}

.card {
  width: 300px;
  margin: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

.card img {
  width: 100%;
  height: auto;
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
}

.card-content {
  padding: 10px;
}

.card-title {
  font-size: 18px;
  font-weight: bold;
}

.card-author {
  font-size: 14px;
  color: #999;
}

.card-summary {
  margin-top: 10px;
}

.pagination {
  display: flex;
  justify-content: center;
  margin-top: 20px;
}
</style>
  